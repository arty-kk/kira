cat >app/emo_engine/persona/stylers/modifiers.py<< EOF
#app/emo_engine/persona/stylers/modifiers.py
import math
import asyncio
import functools
import logging
import random

from datetime import datetime
from typing import Dict

from app.config import settings
from ..executor import EXECUTOR
from ..utils.emotion_math import _clamp, _sigmoid
from ..constants.emotions import (
    PRIMARY_EMOTIONS, SECONDARY_EMOTIONS,
    TERTIARY_EMOTIONS, DRIVE_METRICS,
    SOCIAL_METRICS, COGNITIVE_METRICS,
    STYLE_METRICS, VALID_DYADS, VALID_TRIADS,
    EXTRA_TRIGGER_METRICS,
)

logger = logging.getLogger(__name__)

NOISE_SCALE_PRIMARY = 0.25
NOISE_SCALE_SECONDARY = 0.22
NOISE_SCALE_TERTIARY = 0.2
NOISE_SCALE_DRIVE_SOCIAL = 0.15
NOISE_SCALE_DYADS_TRIADS = 0.15
NOISE_SCALE_COGNITIVE_STYLE = 0.3


STYLE_SEM = asyncio.Semaphore(100)


async def style_modifiers(self) -> Dict[str, float]:
    logger.debug("style_modifiers ▶ start")
    async with self._mods_lock:
        if self._style_mods_version == self.state_version:
            return self._mods_cache.copy()
        self._style_mods_version = self.state_version
        if not hasattr(self, "_fallback_delta"):
            self._fallback_delta = self._rng.uniform(0.03, 0.07)
        FALLBACK_DELTA = self._fallback_delta
        state_snapshot = self.state.copy()
        prev_cache = self._mods_cache.copy()
        rng_seed = self._rng.random()

    async with STYLE_SEM:
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            EXECUTOR,
            _compute_style_modifiers_sync,
            state_snapshot,
            prev_cache,
            rng_seed,
            FALLBACK_DELTA,
        )

    async with self._mods_lock:
        self._mods_cache = {k: round(v, 2) for k, v in result.items()}
        self.state_version += 1
        self._last_prompt_version = -1
        return self._mods_cache.copy()


def _sigma_for(metric: str) -> float:
    if metric in PRIMARY_EMOTIONS:
        return 0.07
    if metric in DRIVE_METRICS:
        return 0.05
    return 0.04


def _fallback_for(metric: str, FALLBACK_DELTA: float) -> float:
    base = 0.45 if metric in PRIMARY_EMOTIONS else 0.5
    return base - FALLBACK_DELTA


def _compute_style_modifiers_sync(
    state: Dict[str, float],
    prev: Dict[str, float],
    rng_seed: float,
    FALLBACK_DELTA: float,
) -> Dict[str, float]:

    rng = random.Random(rng_seed)

    modified: Dict[str, float] = {}

    # Valence & Arousal
    v_norm = _clamp((state.get("valence", 0.0) + 1.0) / 2.0)
    modified["valence_mod"] = v_norm
    a_norm = _clamp(state.get("arousal", 0.5))
    modified["arousal_mod"] = a_norm

    # Primary emotions
    for emo in PRIMARY_EMOTIONS:
        key = f"{emo}_mod"
        base = state.get(emo, _fallback_for(emo, FALLBACK_DELTA))
        noise = rng.gauss(0.0, _sigma_for(emo) * NOISE_SCALE_PRIMARY)
        raw = base + noise
        if key in prev:
            raw = 0.2 * prev[key] + 0.8 * raw
        modified[key] = _clamp(raw)

    # Energy with circadian
    key = "energy_mod"
    base = state.get("energy", _fallback_for("energy", FALLBACK_DELTA))
    noise = rng.gauss(0.0, _sigma_for("energy") * NOISE_SCALE_PRIMARY)
    raw_e = base + noise
    if key in prev:
        raw_e = 0.2 * prev[key] + 0.8 * raw_e
    fatigue_penalty = 0.4 * state.get("fatigue", 0.0)
    now = datetime.now()
    hour = now.hour + now.minute / 60.0
    circadian = 1.0 + settings.CIRCADIAN_AMPLITUDE * math.sin(2 * math.pi * (hour / 24.0))
    modified[key] = _clamp(raw_e * (1 - fatigue_penalty) * circadian)

    # Fatigue
    key = "fatigue_mod"
    base = state.get("fatigue", _fallback_for("fatigue", FALLBACK_DELTA))
    noise = rng.gauss(0.0, _sigma_for("fatigue") * NOISE_SCALE_PRIMARY)
    raw_f = base + noise
    if key in prev:
        raw_f = 0.2 * prev[key] + 0.8 * raw_f
    modified[key] = _clamp(raw_f)

    # Secondary emotions
    for prim, subs in SECONDARY_EMOTIONS.items():
        for sec, fn in subs.items():
            key = f"{sec}_mod"
            base = fn(state)
            noise = rng.gauss(0.0, _sigma_for(sec) * NOISE_SCALE_SECONDARY)
            raw = base + noise
            if key in prev:
                raw = 0.2 * prev[key] + 0.8 * raw
            modified[key] = _clamp(raw)

    # Tertiary emotions
    for sec, subs in TERTIARY_EMOTIONS.items():
        for ter, fn in subs.items():
            key = f"{ter}_mod"
            base = fn(state)
            noise = rng.gauss(0.0, _sigma_for(ter) * NOISE_SCALE_TERTIARY)
            raw = base + noise
            if key in prev:
                raw = 0.2 * prev[key] + 0.8 * raw
            modified[key] = _clamp(raw)

    # Drive, social & extra-trigger metrics
    for metric in DRIVE_METRICS + SOCIAL_METRICS + EXTRA_TRIGGER_METRICS:
        key = f"{metric}_mod"
        base = state.get(metric, _fallback_for(metric, FALLBACK_DELTA))
        noise = rng.gauss(0.0, _sigma_for(metric) * NOISE_SCALE_DRIVE_SOCIAL)
        raw = base + noise
        if key in prev:
            raw = 0.2 * prev[key] + 0.8 * raw
        modified[key] = _clamp(raw)

    # Dyads & Triads
    for emo_name in list(VALID_DYADS.values()) + list(VALID_TRIADS.values()):
        key = f"{emo_name}_mod"
        if key in modified:
            continue
        base = state.get(emo_name, 0.0)
        noise = rng.gauss(0.0, _sigma_for(emo_name) * NOISE_SCALE_DYADS_TRIADS)
        raw = base + noise
        if key in prev:
            raw = 0.2 * prev[key] + 0.8 * raw
        modified[key] = _clamp(raw)

    # Cognitive & Style metrics
    for metric in COGNITIVE_METRICS + STYLE_METRICS:
        key = f"{metric}_mod"
        base = state.get(metric, _fallback_for(metric, FALLBACK_DELTA))
        if metric == "flirtation":
            valence_norm = (state.get("valence", 0.0) + 1.0) / 2.0
            raw = valence_norm * state.get("sexual_arousal", 0.0)
        elif metric == "sarcasm":
            raw = base * (1.0 - abs(state.get("valence", 0.0) - 0.2))
        elif metric == "humor":
            raw = base * (1 - 0.5 * state.get("fatigue", 0.0))
        else:
            raw = base
        noise = rng.gauss(0.0, _sigma_for(metric) * NOISE_SCALE_COGNITIVE_STYLE * 1.2)
        raw = raw + noise
        if key in prev:
            raw = 0.2 * prev[key] + 0.8 * raw
        if metric == "profanity":
            raw = _sigmoid(raw, k=5, mid=0.35)
        modified[key] = _clamp(raw)

    return modified
EOF