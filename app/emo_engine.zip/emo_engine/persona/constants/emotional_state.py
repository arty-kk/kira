cat >app/emo_engine/persona/constants/emotional_state.py<< 'EOF'
#app/emo_engine/persona/constants/emotional_state.py
from __future__ import annotations

from typing import Dict, Optional, Tuple, List
from .tone_map import TONE_MAP, Tone


MIN_GLOBAL_THR = 0.10
TOP_K = 3


def compute_emotional_state(
    state: Dict[str, float],
    mods: Dict[str, float],
    dominant: Optional[str] = None,
    *,
    allow_mixed: bool = True,
) -> str:

    if dominant:
        return dominant

    scores: List[Tuple[Tone, float]] = []
    for key, tone in TONE_MAP.items():
        v = mods.get(key, state.get(key.replace("_mod", ""), 0.0))
        v = max(0.0, min(1.0, v))
        scores.append((tone, v))

    scores.sort(key=lambda kv: kv[1], reverse=True)
    if not scores:
        return "Neutral"

    dyn_thr = max(MIN_GLOBAL_THR, scores[0][1] * 0.15)
    chosen = [(t, v) for t, v in scores if v >= dyn_thr][:TOP_K]
    if not chosen:
        return "Neutral"

    if not allow_mixed or len(chosen) == 1:
        return chosen[0][0].name

    total = sum(v for _, v in chosen)
    parts = [f"{t.name}:{int(round(v / total * 100))}" for t, v in chosen]
    return "+".join(parts)
EOF