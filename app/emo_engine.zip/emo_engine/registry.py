cat >app/emo_engine/registry.py<< 'EOF'
#app/emo_engine/registry.py
from __future__ import annotations

import time
import asyncio
import functools
import logging

from collections import OrderedDict
from .persona.core import Persona
from app.config import settings

_TTL   = 3600
_MAX   = getattr(settings, "PERSONA_CACHE_MAX", 300)
_cache: "OrderedDict[tuple[int,int], tuple[Persona, float]]" = OrderedDict()
_lock  = asyncio.Lock()


logger = logging.getLogger(__name__)


def _purge() -> None:
    now = time.time()
    stale = [cid for cid, (_, ts) in _cache.items() if now - ts > _TTL]
    for cid in stale:
        _cache.pop(cid, None)
    while len(_cache) > _MAX:
        _cache.popitem(last=False)
    if stale:
        logger.debug("purged %d persona(s)", len(stale))


async def get_persona(chat_id: int, user_id: int | None = None, *, group_mode: bool = False) -> Persona:
    t = time.time()
    key = (chat_id, 0) if group_mode else (chat_id, user_id or 0)
    entry = _cache.get(key)
    if entry:
        persona, _ = entry
        logger.debug("persona.cache hit key=%s", key)
        async with _lock:
            _cache[key] = (persona, time.time())
        return persona

    logger.debug("persona.cache miss key=%s – constructing", key)
    persona = Persona(chat_id)

    async with _lock:
        _purge()
        _cache[key] = (persona, time.time())
        _purge()
    logger.debug("persona.ready key=%s dt=%.3fs", key, time.time() - t)
    return persona
EOF